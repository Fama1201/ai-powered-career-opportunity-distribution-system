CREATE TABLE student (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT,
  skills TEXT,
  career_interest TEXT,
  discord_id TEXT UNIQUE,
  cv_text TEXT
);

CREATE TABLE opportunities (
  opportunity_id TEXT,
  discord_id TEXT,
  title TEXT,
  description TEXT,
  job_type TEXT,
  application_deadline DATE,
  url TEXT,
  wage TEXT,
  home_office TEXT,
  benefits TEXT,
  formal_requirements TEXT,
  technical_requirements TEXT,
  contact_person TEXT,
  company TEXT,
  PRIMARY KEY (opportunity_id, discord_id)
);

CREATE TABLE feedback (
  id SERIAL PRIMARY KEY,
  feedback_text TEXT,
  stars INTEGER,
  discord_id TEXT
);